<?php
// Include and initialize DB class
require_once 'dashboard/config.php';
$db = new DB();

// Fetch the images data
$condition = array('where' => array('status' => 1));
$images = $db->getRows('latest_cars', $condition);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Used Cars</title>
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/mdb.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body style="font-family: 'Barlow', sans-serif;">

<header>
  <!--Navbar -->
<nav class="px-5 navbar navbar-expand-lg navbar-dark">
  <a class="navbar-brand" href="#"><img class="" src="img/logo.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
    aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active"><a class="nav-link black-text fnt-sbold mr-2" href="index.php">HOME<span class="sr-only">(current)</span></a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="used-cars.html">USED CARS</a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="warranty.html">WARRANTY</a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="part-exchange.html">PART EXCHANGE</a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="#">LOCKSMITH</a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="contact.html">CONTACT US</a></li>

    </ul>
  </div>
</nav>
<!--/.Navbar -->
</header>

<div class="jumbotron card card-image " style="background-image: url('img/2.jpg');">
    <div class="text-white text-center py-5 px-4">
    <div>
        <h1 class="card-title h1-responsive pt-3 mb-5 font-weight-bold">Classified Shops</h1>
    </div>
    </div>
</div>

  <div class="container py-5">
    <h2 class="heading">Latest Premium Cars</h2>
    <div class="row mx-0">
      <div class="card-deck">
        <div class="row mx-0">
          <?php
          if(!empty($images)){
              foreach($images as $row){
                  $uploadDir = 'dashboard/uploads/latest_cars/';
                  $imageURL = $uploadDir.$row["file_name"];
          ?>

          <div class="card mb-4">
            <div class="view overlay">
              <img class="card-img-top" src="<?php echo $imageURL;?>" alt="Card image cap">
              <a href="#!"><div class="mask rgba-white-slight"></div></a>
            </div>
            <div class="card-body">
              <h5 class="card-title pt-3 font-weight-bold"><?php echo $row['title']; ?> <span class="siteclr float-right">$<?php echo $row['price']; ?></span></h5>
              <p class="card-text"><span class= "grey-text">Build year :</span><?php echo $row['year']; ?></p>
              <hr>
              <p class=" grey-text"><i class="fa fa-tools mx-2"></i><?php echo $row['engine_size']; ?> <i class="fa fa-cogs mx-2"></i><?php echo $row['transmission']; ?> <i class="fa fa-oil-can mx-2"></i><?php echo $row['oil']; ?></p>
            </div>
          </div>

          <?php 
          }
            }?>
        </div>
      </div>
    </div>
    <div class="text-center mb-4"><button type="button" class="btn btn-siteclr">VIEW COLLECTIONS</button></div>

  </div>

  <footer class="page-footer font-small pt-4">
    <div class="container text-center text-md-left">
      <div class="row text-center text-md-left mt-3 pb-3">
          <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
            <img class="imgcstm" src="img/footer.png">
            <p><i class="fa fa-user mr-2"></i>Demo address, Demo</p>
            <p><i class="fa fa-user mr-2"></i>demo@gmail.com</p>
            <p><i class="fa fa-user mr-2"></i>+91 9123456789</p>
          </div>
        <hr class="w-100 clearfix d-md-none">
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
          <h4 class="mb-4 font-weight-bold siteclr">Page Info</h4>
          <p><a href="#!">Home</a></p>
          <p><a href="#!">Used Cars</a></p>
          <p><a href="#!">Warranty</a></p>
          
        </div>
        <hr class="w-100 clearfix d-md-none">
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
          <h4 class="mb-4 font-weight-bold siteclr">Quick links</h4>
          <p><a href="#!">Part Exchange</a></p>
          <p><a href="#!">Locksmith</a></p>
          <p><a href="#!">Contact Us</a></p>
        </div>
        <hr class="w-100 clearfix d-md-none">
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
          <h4 class=" mb-4 font-weight-bold siteclr">Subscribe us</h4>
          <form class="input-group mb-4">
            <input type="text" class="form-control form-control-sm form-cstm" placeholder="Your email"
              aria-label="Your email" aria-describedby="basic-addon2">
            <div class="input-group-append">
              <button class="btn btn-sm btn-site my-0" type="button">Sign up</button>
            </div>
          </form>
          <ul class="list-unstyled list-inline text-center">
            <li class="list-inline-item">
              <a class="btn-floating btn-sm  mx-1" style="background-color:#475993">
                <i class="fab fa-facebook-f"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm  mx-1" style="background-color:#5f9dec">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1" style="background-color:#ec4a89">
                <i class="fab fa-google-plus-g"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1" style="background-color:#0082ca">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </li>   
          </ul>
        </div>
      </div>
      <hr>
      <div class="row d-flex align-items-center">
        <div class="col-md-7 col-lg-8">
          <p class="text-center text-md-left">© 2020 Copyright:
            <a href="https://mdbootstrap.com/">
              <strong> All Right Reserved</strong>
            </a>
          </p>
        </div>
        <div class="col-md-5 col-lg-4 ml-lg-0">
          <div class="text-center text-md-right">
            <ul class="list-unstyled list-inline">
              <li class="list-inline-item">
               Terms of Use
              </li>
              <li class="list-inline-item">
                Privacy policy
               </li>
               <li class="list-inline-item">
                Cookie settings
               </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <script type="text/javascript"></script>

</body>
</html>
