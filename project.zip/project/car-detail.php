<?php


/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'project');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){

    // Start session
    session_start();
    
    // Prepare a select statement
    $sql = "SELECT * FROM spec_details WHERE id = ?";
    
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $title = $row["title"];
                $price = $row["price"];
                $reg_num = $row["reg_num"];
                $date_of_reg = $row["date_of_reg"];
                $mileage = $row["mileage"];
                $fuel_type = $row["fuel_type"];
                $colour = $row["colour"];
                $doors = $row["doors"];
                $car_key = $row["car_key"];
                $sat_nav = $row["sat_nav"];
                $mot_exp = $row["mot_exp"];
                $serv_his = $row["serv_his"];
                $last_serv = $row["last_serv"];
                $inter_con = $row["inter_con"];
                $exter_con = $row["exter_con"];
                $tyre_con = $row["tyre_con"];
                $warranty = $row["warranty"];
                $v5_docx = $row["v5_docx"];
                $hpi_check = $row["hpi_check"];
                $hpi_status = $row["hpi_status"];
                $category = $row["category"];
                $vin = $row["vin"];
                $doc_ref_num = $row["doc_ref_num"];
            }
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($link);
} 
?>
<?php

// Include packages and files for PHPMailer and SMTP protocol

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Initialize PHP mailer, configure to use SMTP protocol and add credentials

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Mailer = "smtp";

// $mail->SMTPDebug  = 1;
$mail->SMTPAuth   = TRUE;
$mail->SMTPSecure = "tls";
$mail->Port       = 587;
$mail->Host       = "smtp.gmail.com";
$mail->Username   = "surya.g@cube84.com";
$mail->Password   = "zebrina1224";


$success = "";
$error = "";
$name = $message = $phone = $email = "";
$errors = array('name' => '', 'email' => '', 'phone' => '', 'message' => '');

if (isset($_POST["submit"])) {
    if (empty(trim($_POST["name"]))) {
        $errors['name'] = "Your name is required";
    }else {
      $name = SanitizeString($_POST["name"]);
      if (!preg_match("/^[a-zA-Z\d\s]+$/", $name)) {
          $errors["name"] = "Only letters, spaces allowed";
      }
  }

    if (empty(trim($_POST["phone"]))) {
      $errors['phone'] = "Your phone is required";
    }else {
      $message = SanitizeString($_POST["phone"]);
      if (!preg_match("/^\d{10}$/", $message)) {
          $errors["phone"] = "Only numbers allowed";
      }
    }

    if (empty(trim($_POST["email"]))) {
        $errors["email"] = "Your email is required";
    } else {
        $email = SanitizeString($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors["email"] = "Pls give a proper email address";
        }
    }

    if (empty(trim($_POST["message"]))) {
        $errors["message"] = "Please type your message";
    } else {
        $message = SanitizeString($_POST["message"]);
        if (!preg_match("/^[a-zA-Z\d\s]+$/", $message)) {
            $errors["message"] = "Only letters, spaces and maybe numbers allowed";
        }
    }

    if (array_filter($errors)) {
    } else {
        try {

            $mail->setFrom('zebrinadrlng@gmail.com', 'Surya');

            $mail->addAddress($email, $name);

            $mail->Subject = 'Build a contact form with PHP';

            $mail->Body = "Name = ". $name . "\r\n Email = " . $email . "\r\n Message = " . $message ."\r\n Mobile number =". $phone;

            // send mail

            $mail->send();

            // empty users input

            $name = $message = $phone = $email = "";

            $success = "Message sent successfully";
        } catch (Exception $e) {

            // echo $e->errorMessage(); use for testing & debugging purposes
            $error = "Sorry message could not send, try again";
        } catch (Exception $e) {

            // echo $e->getMessage(); use for testing & debugging purposes
            $error = "Sorry message could not send, try again";
        }
    }
}

function SanitizeString($var)
{
    $var = strip_tags($var);
    $var = htmlentities($var);
    return stripslashes($var);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>SAMPLE</title>
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/mdb.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    .md-form>label{
      overflow:auto;
      text-overflow: unset;
      white-space: normal;
    }
        .error {
            color: white;
            background-color: crimson;
            border-radius: 7px;
            text-align: center;
        }

        .success {
            background-color: darkgreen;
            color: white;
            border-radius: 7px;
            text-align: center;
        }

    #carousel-example-2 .carousel-indicators{
    position: absolute;
    top: 100%;
    left: 0;
    height: auto;
    width: auto; 
    }
    #carousel-example-2 .carousel-indicators li{
        text-indent:0;
        display:inherit;
        float:left;
        width: 100%;
        height: 100%!important;
        margin:5px 0px;
    }
    #carousel-example-2 .carousel-indicators li img{
        width: 95%;
        height: 100px;
        border:2px solid #CCCCCC;
        padding: 2px;
    }
    #carousel-example-2 .carousel-indicators .active img{
        border:2px solid #04BEF5;
    }
    #carousel-example-2 .carousel-indicators .active{
        margin:5px 0px;
        width: 100%;
        height: 100%!important;
    }
    @media screen and (min-width:320px) and (max-width:360px) {
      #carousel-example-2 .carousel-indicators{
        top:115px;
        left:95px;
    }
    #carousel-example-2 .carousel-indicators li img{
        width:95%;
        height:50px;
    }
    #carousel-example-2 .carousel-indicators li{
        width:20%;
        height:50px;
    }
    #carousel-example-2 .carousel-indicators .active{
        width:20%;
        height:50px;
    }
}
@media screen and (min-width:768px) and (max-width:980px){
  #carousel-example-2 .carousel-indicators{
        top:240px;
        left:213px;
    }
    #carousel-example-2 .carousel-indicators li img{
      height:50px!important
    }
}
  </style>
</head>
<body style="font-family: 'Barlow', sans-serif;">

<header>
  <!--Navbar -->
<nav class="px-5 navbar navbar-expand-lg navbar-dark">
  <a class="navbar-brand" href="#"><img class="" src="img/logo.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
    aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active"><a class="nav-link black-text fnt-sbold mr-2" href="index.php">HOME<span class="sr-only">(current)</span></a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="used-cars.php">USED CARS</a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="warranty.html">WARRANTY</a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="part-exchange.html">PART EXCHANGE</a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="#">LOCKSMITH</a></li>
      <li class="nav-item"><a class="nav-link black-text fnt-sbold mr-2" href="contact.html">CONTACT US</a></li>

    </ul>
  </div>
</nav>
<!--/.Navbar -->
</header>

<div class="jumbotron card card-image " style="background-image: url('img/2.jpg');">
    <div class="text-white text-center py-5 px-4">
    <div>
        <h1 class="card-title h1-responsive pt-3 mb-5 font-weight-bold">Product Details</h1>
    </div>
    </div>
</div>

 <div class="container py-5 mb-5">
    <div class="row">
        <div class="col-md-8">
            <h2 class="pb-3 font-weight-bold"><span class="float-right siteclr"></span></h2>
                    <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
                        <!-- <ol class="carousel-indicators">
                            <li data-target="#carousel-example-2" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-example-2" data-slide-to="1"></li>
                            <li data-target="#carousel-example-2" data-slide-to="2"></li>
                        </ol> -->
                        <ul class="carousel-indicators">
                            <li data-target="#carousel-example-2" data-slide-to="0" class="active"><img src="img/1.jpg"></li>
                            <li data-target="#carousel-example-2" data-slide-to="1"><img src="img/2.jpg"></li>
                            <li data-target="#carousel-example-2" data-slide-to="2"><img src="img/3.jpg"></li>
                        </ul>
                    <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                                <div class="view">
                                    <img class="d-block w-100" src="img/1.jpg" alt="First slide">
                                </div>
                        </div>
                        <div class="carousel-item">
                            <div class="view">
                                <img class="d-block w-100" src="img/2.jpg" alt="Second slide">
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="view">
                                <img class="d-block w-100" src="img/3.jpg" alt="Third slide">
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <div class="col-md-3 offset-md-1 mt-5">
            <button type="button" class="btn btn-siteclr mt-5" data-toggle="modal" data-target="#modalLoginForm"><i class="fa fa-info-circle mr-2"></i>Request More Info</button><br>
            <button type="button" class="btn btn-siteclr mt-5" data-toggle="modal" data-target="#modalLoginForm1"><i class="fa fa-car mr-2"></i>Book a Test Drive</button>
        </div>
    </div>
 </div>

 <div class="container py-5 mt-5">
    <div class="row justify-content-center">
        <h2 class="font-weight-bold mt-5 mb-4">Specification Details</h2>
</div>

              <div class="content mb-5 pb-5">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card strpied-tabled-with-hover">
                                <div class="card-body table-full-width table-responsive">
                                    <div class="row mx-3 justify-content-center">
                                      <div class="col-md-8">
                                        <?php
                                            
                                            // Attempt select query execution
                                            $sql = "SELECT * FROM spec_details";
                                            if($result = mysqli_query($link, $sql)){
                                                if(mysqli_num_rows($result) > 0){
                                                  while($row = mysqli_fetch_array($result)){
                                                    echo '<table class="table table-hover table-bordered table-striped">';
                                                        echo "<tbody>";
                                                            echo "<tr>";
                                                                echo "<td width='50%'>Title</td>";
                                                                echo "<td width='50%'>" . $row['title'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Price</td>";
                                                                echo "<td>" . $row['price'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Registration Number</td>";
                                                                echo "<td>" . $row['reg_num'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Date of Registration</td>";
                                                                echo "<td>" . $row['date_of_reg'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Mileage</td>";
                                                                echo "<td>" . $row['mileage'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Type of Fuel</td>";
                                                                echo "<td>" . $row['fuel_type'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Colour</td>";
                                                                echo "<td>" . $row['colour'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Number of doors</td>";
                                                                echo "<td>" . $row['doors'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Number of keys</td>";
                                                                echo "<td>" . $row['car_key'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Sat Nav</td>";
                                                                echo "<td>" . $row['sat_nav'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>MOT Expire date</td>";
                                                                echo "<td>" . $row['mot_exp'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Service history</td>";
                                                                echo "<td>" . $row['serv_his'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Last Serviced on</td>";
                                                                echo "<td>" . $row['last_serv'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Interior Condition</td>";
                                                                echo "<td>" . $row['inter_con'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Exterior Condition</td>";
                                                                echo "<td>" . $row['exter_con'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Tyre Condition</td>";
                                                                echo "<td>" . $row['tyre_con'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Warranty</td>";
                                                                echo "<td>" . $row['warranty'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>V5 Document</td>";
                                                                echo "<td>" . $row['v5_docx'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>HPI Check</td>";
                                                                echo "<td>" . $row['hpi_check'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>HPI status</td>";
                                                                echo "<td>" . $row['hpi_status'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Category</td>";
                                                                echo "<td>" . $row['category'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>VIN/Chassls/Frame Number</td>";
                                                                echo "<td>" . $row['vin'] . "</td>";
                                                            echo "</tr>";
                                                            echo "<tr>";
                                                                echo "<td>Document Reference Number</td>";
                                                                echo "<td>" . $row['doc_ref_num'] . "</td>";
                                                            echo "</tr>";
                                                            
                                                        }
                                                        echo "</tbody>";                            
                                                    echo "</table>";
                                                    // Free result set
                                                    mysqli_free_result($result);
                                                } else{
                                                    echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                                                }
                                            } else{
                                                echo "Oops! Something went wrong. Please try again later.";
                                            }
                        
                                            // Close connection
                                            mysqli_close($link);
                                        ?>
                                      </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    </div>
 </div>

  <footer class="page-footer font-small pt-4">
    <div class="container text-center text-md-left">
      <div class="row text-center text-md-left mt-3 pb-3">
          <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
            <img class="imgcstm" src="img/footer.png">
            <p><i class="fa fa-user mr-2"></i>Demo address, Demo</p>
            <p><i class="fa fa-user mr-2"></i>demo@gmail.com</p>
            <p><i class="fa fa-user mr-2"></i>+91 9123456789</p>
          </div>
        <hr class="w-100 clearfix d-md-none">
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
          <h4 class="mb-4 font-weight-bold siteclr">Page Info</h4>
          <p><a href="#!">Home</a></p>
          <p><a href="#!">Used Cars</a></p>
          <p><a href="#!">Warranty</a></p>
          
        </div>
        <hr class="w-100 clearfix d-md-none">
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
          <h4 class="mb-4 font-weight-bold siteclr">Quick links</h4>
          <p><a href="#!">Part Exchange</a></p>
          <p><a href="#!">Locksmith</a></p>
          <p><a href="#!">Contact Us</a></p>
        </div>
        <hr class="w-100 clearfix d-md-none">
        <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
          <h4 class=" mb-4 font-weight-bold siteclr">Subscribe us</h4>
          <form class="input-group mb-4">
            <input type="text" class="form-control form-control-sm form-cstm" placeholder="Your email"
              aria-label="Your email" aria-describedby="basic-addon2">
            <div class="input-group-append">
              <button class="btn btn-sm btn-site my-0" type="button">Sign up</button>
            </div>
          </form>
          <ul class="list-unstyled list-inline text-center">
            <li class="list-inline-item">
              <a class="btn-floating btn-sm  mx-1" style="background-color:#475993">
                <i class="fab fa-facebook-f"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm  mx-1" style="background-color:#5f9dec">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1" style="background-color:#ec4a89">
                <i class="fab fa-google-plus-g"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1" style="background-color:#0082ca">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </li>   
          </ul>
        </div>
      </div>
      <hr>
      <div class="row d-flex align-items-center">
        <div class="col-md-7 col-lg-8">
          <p class="text-center text-md-left">© 2020 Copyright:
            <a href="https://mdbootstrap.com/">
              <strong> All Right Reserved</strong>
            </a>
          </p>
        </div>
        <div class="col-md-5 col-lg-4 ml-lg-0">
          <div class="text-center text-md-right">
            <ul class="list-unstyled list-inline">
              <li class="list-inline-item">
               Terms of Use
              </li>
              <li class="list-inline-item">
                Privacy policy
               </li>
               <li class="list-inline-item">
                Cookie settings
               </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </footer>


<div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h4 class="modal-title w-100 font-weight-bold">Get Information</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
      <div class="success"><?php echo $success ?></div>
      <div class="error"><?php echo $error ?></div>
      <form action="car-detail.php" method="post">
        <div class="modal-body mx-3">
          <div class="mb-5">
              <input type="text" id="name" name="name" class="form-control validate" value="<?php echo htmlspecialchars($name) ?>">
              <label data-error="wrong" data-success="right" for="defaultForm-name">Name</label>
          </div>
          <div class="mb-5">
              <input type="number" id="phone" name="phone" class="form-control validate" value="<?php echo htmlspecialchars($phone) ?>">
              <label data-error="wrong" data-success="right" for="defaultForm-number">Phone Number</label>
          </div>
          <div class="mb-5">
            <input type="email" id="email" name="email" class="form-control validate" value="<?php echo htmlspecialchars($email) ?>">
            <label data-error="wrong" data-success="right" for="defaultForm-email">Your email</label>
          </div>
          <div class=" mb-5">
              <textarea id="message" name="message" class="form-control validate" value="<?php echo htmlspecialchars($message) ?>"></textarea>
              <label data-error="wrong" data-success="right" for="defaultForm-subject">Subject</label>
          </div>

        </div>
        <div class="modal-footer d-flex justify-content-center">
          <input type="submit" class="btn btn-siteclr" name="submit" id="submit" value="Request Information"></input>
        </div>
      </form>
    </div>
  </div>
</div>
<div class="modal fade" id="modalLoginForm1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header text-center">
          <h4 class="modal-title w-100 font-weight-bold">Book Test Drive</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        
                <form action="car-detail.php" method="post">
                  <div class="modal-body mx-3">
                    <div class="md-form mb-5">
                        <input type="text" id="name" name="name" class="form-control validate" value="<?php echo htmlspecialchars($name) ?>">
                        <label data-error="wrong" data-success="right" for="defaultForm-name">Name</label>
                    </div>
                    <div class="md-form mb-5">
                        <input type="number" id="phone" name="phone" class="form-control validate" value="<?php echo htmlspecialchars($phone) ?>">
                        <label data-error="wrong" data-success="right" for="defaultForm-number">Phone Number</label>
                    </div>
                    <div class="md-form mb-5">
                      <input type="email" id="email" name="email" class="form-control validate" value="<?php echo htmlspecialchars($email) ?>">
                      <label data-error="wrong" data-success="right" for="defaultForm-email">Your email</label>
                    </div>
                    <div class="md-form mb-5">
                        <input type="text" id="modal" name="modal" class="form-control validate" value="<?php echo htmlspecialchars($modal) ?>">
                        <label data-error="wrong" data-success="right" for="defaultForm-modal">Modal</label>
                    </div>
                    <div class="md-form mb-5">
                      <input type="date" id="date" name="date" class="form-control validate" value="<?php echo htmlspecialchars($date) ?>">
                      <label data-error="wrong" data-success="right" for="defaultForm-date">Select Date</label>
                  </div>
                  <div class="modal-footer d-flex justify-content-center">
                    <input type="submit" class="btn btn-siteclr" name="submit" id="submit" value="Request Information"></input>
                  </div>
                  
                <div class="success"><?php echo $success ?></div>
                <div class="error"><?php echo $error ?></div>
                </form>
      </div>
    </div>
  </div>

  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <script type="text/javascript"></script>

</body>
</html>
