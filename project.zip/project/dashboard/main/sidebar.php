<div class="sidebar" data-image="../assets/img/sidebar.jpg">
           
            <div class="sidebar-wrapper">
                <div class="logo">
                    <a href="javascript:;" class="simple-text">
                      <img src="../../img/logo.png">
                    </a>
                </div>
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../main/index.php">
                            <i class="fa fa-chart-pie"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../banner_sliders/manage_slider.php">
                            <i class="fa fa-film"></i>
                            <p>Slider</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../latest_cars/manage_latest.php">
                            <i class="fa fa-car"></i>
                            <p>Latest Cars</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../specifications/index.php">
                            <i class="fa fa-cog"></i>
                            <p>Specification</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>