<?php
// Start session
session_start();

$postData = $imgData = array();

// Get session data
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';

// Get status message from session
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}

// Get posted data from session
if(!empty($sessData['postData'])){
    $postData = $sessData['postData'];
    unset($_SESSION['sessData']['postData']);
}

// Get image data
if(!empty($_GET['id'])){
    // Include and initialize DB class
    require_once '../config.php';
    $db = new DB();
    
    $conditions['where'] = array(
        'id' => $_GET['id'],
    );
    $conditions['return_type'] = 'single';
    $imgData = $db->getRows('specifications', $conditions);
}

// Pre-filled data
$imgData = !empty($postData)?$postData:$imgData;

// Define action
$actionLabel = !empty($_GET['id'])?'Edit':'Add';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../../img/logo.png">
    <link rel="icon" type="image/png" href="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title> Admin Dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous"/>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500&display=swap" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <?php include("../main/sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <?php include("../main/navbar.php"); ?>
            <!-- End Navbar -->



<!-- Display status message -->
<?php if(!empty($statusMsg)){ ?>
<div class="col-xs-12">
    <div class="alert alert-<?php echo $statusMsgType; ?>"><?php echo $statusMsg; ?></div>
</div>
<?php } ?>


<div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header ">
                                    <div class="float-left">
                                        <h4 class="card-title">Car Specifications | Add Data </h4>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <form method="post" action="postAction_spec.php" enctype="multipart/form-data">
                                        <div class="form-group row">
                                            <div class="col-md-3">
                                                <label>Registration Number</label>
                                                <input type="text" name="reg_num" class="form-control" placeholder="Enter Registration No." value="<?php echo !empty($imgData['reg_num'])?$imgData['reg_num']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Date of Registration</label>
                                                <input type="date" name="date_of_reg" class="form-control" placeholder="Enter Date of Registration" value="<?php echo !empty($imgData['date_of_reg'])?$imgData['date_of_reg']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Title</label>
                                                <input type="text" name="title" class="form-control" placeholder="Enter Title" value="<?php echo !empty($imgData['title'])?$imgData['title']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Price</label>
                                                <input type="number" name="price" class="form-control" placeholder="Enter Price" value="<?php echo !empty($imgData['price'])?$imgData['price']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Mileage</label>
                                                <input type="text" name="mileage" class="form-control" placeholder="Enter Mileage" value="<?php echo !empty($imgData['mileage'])?$imgData['mileage']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Colour</label>
                                                <input type="text" name="colour" class="form-control" placeholder="Enter Colour" value="<?php echo !empty($imgData['colour'])?$imgData['colour']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>No. of doors</label>
                                                <input type="number" name="doors" class="form-control" placeholder="Enter No. of Doors" value="<?php echo !empty($imgData['doors'])?$imgData['doors']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>No. of Keys</label>
                                                <input type="number" name="keys" class="form-control" placeholder="Enter No. of Keys" value="<?php echo !empty($imgData['keys'])?$imgData['keys']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Sat Nav<br><span>(Yes/No)</span></label>
                                                <input type="text" name="sat_nav" class="form-control" placeholder="Enter Oil" value="<?php echo !empty($imgData['sat_nav'])?$imgData['sat_nav']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>HPI Check<br><span>(Clear/Not Checked)</span></label>
                                                <input type="text" name="hpi_check" class="form-control" placeholder="Enter HPI Check" value="<?php echo !empty($imgData['hpi_check'])?$imgData['hpi_check']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>HPI Status<br><span>(Yes/No)</span></label>
                                                <input type="text" name="hpi_status" class="form-control" placeholder="Enter HPI Status" value="<?php echo !empty($imgData['hpi_status'])?$imgData['hpi_status']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Type of Fuel<br><span>(Petrol/Diesel/Petrol&Hybrid/Electric)</span></label>
                                                <input type="text" name="fuel_type" class="form-control" placeholder="Enter Type of Fuel" value="<?php echo !empty($imgData['fuel_type'])?$imgData['fuel_type']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Service history<br><span> (Full/Partial/10 stamp/No/MOT history only)</span></label>
                                                <input type="text" name="serv_his" class="form-control" placeholder="Enter Service History" value="<?php echo !empty($imgData['serv_his'])?$imgData['serv_his']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Warranty<br><span>(6 Months/1 Year/More Options)</span></label>
                                                <input type="text" name="warranty" class="form-control" placeholder="Enter Warranty" value="<?php echo !empty($imgData['warranty'])?$imgData['warranty']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>V5 Document<br><span>(Yes/No/We will apply directly to the purchaser)</span></label>
                                                <input type="text" name="v5_docx" class="form-control" placeholder="Enter V5 Document" value="<?php echo !empty($imgData['v5_docx'])?$imgData['v5_docx']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Category<br><span>(N/D/S/B/No Damage Reported)</span></label>
                                                <input type="text" name="category" class="form-control" placeholder="Enter Category" value="<?php echo !empty($imgData['category'])?$imgData['category']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>MOT Expire date</label>
                                                <input type="date" name="mot_exp" class="form-control" placeholder="Enter MOT Expire date" value="<?php echo !empty($imgData['mot_exp'])?$imgData['mot_exp']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Last Serviced on</label>
                                                <input type="date" name="last_serv" class="form-control" placeholder="Enter Last Serviced on" value="<?php echo !empty($imgData['last_serv'])?$imgData['last_serv']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>VIN/Chassls/Frame Number</label>
                                                <input type="text" name="vin" class="form-control" placeholder="Enter VIN/Chassls/Frame Number" value="<?php echo !empty($imgData['vin'])?$imgData['vin']:''; ?>" >
                                            </div>
                                            <div class="col-md-3">
                                                <label>Document Reference Number</label>
                                                <input type="text" name="doc_ref_num" class="form-control" placeholder="Enter Document Reference Number" value="<?php echo !empty($imgData['doc_ref_num'])?$imgData['doc_ref_num']:''; ?>" >
                                            </div>
                                            <div class="col-md-4">
                                                <label>Interior Condition <br><span>(Excellent/Very Good/Good/Normal)</span></label>
                                                <input type="text" name="inter_con" class="form-control" placeholder="Enter Interior Condition" value="<?php echo !empty($imgData['inter_con'])?$imgData['inter_con']:''; ?>" >
                                            </div>
                                            <div class="col-md-4">
                                                <label>Exterior Condition<br><span>(Excellent/Very Good/Good/Normal)</span></label>
                                                <input type="text" name="exter_con" class="form-control" placeholder="Enter Exterior Condition" value="<?php echo !empty($imgData['exter_con'])?$imgData['exter_con']:''; ?>" >
                                            </div>
                                            <div class="col-md-4">
                                                <label>Tyre Condition<br><span>(Excellent/Very Good/Good/Legal Limit)</span></label>
                                                <input type="text" name="tyre_con" class="form-control" placeholder="Enter Tyre Condition" value="<?php echo !empty($imgData['tyre_con'])?$imgData['tyre_con']:''; ?>" >
                                            </div>
                                            <div class="col-md-4">
                                            <label>Image</label>
                                            <?php if(!empty($imgData['file_name'])){ ?>
                                                <img width="250" style="padding:10px" src="../uploads/specifications/<?php echo $imgData['file_name']; ?>">
                                            <?php } ?>
                                            <input type="file" name="image" class="form-control" >
                                            </div>
                                        </div>
                                        <a href="manage_spec.php" class="btn btn-secondary">Back</a>
                                        <input type="hidden" name="id" value="<?php echo !empty($imgData['id'])?$imgData['id']:''; ?>">
                                        <input type="submit" name="imgSubmit" class="btn btn-success" value="SUBMIT">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
</html>


