<?php
// Start session
session_start();

// Include and initialize DB class
require_once '../config.php';
$db = new DB();

$tblName = 'specifications';

// Set default redirect url
$redirectURL = 'manage_spec.php';

$statusMsg = '';
$sessData = array();
$statusType = 'danger';
if(isset($_POST['imgSubmit'])){
    
     // Set redirect url
    $redirectURL = 'addEdit_spec.php';

    // Get submitted data
    $reg_num    = $_POST['reg_num'];
    $date_of_reg    = $_POST['date_of_reg'];
    $mileage     = $_POST['mileage'];
    $fuel_type    = $_POST['fuel_type'];
    $colour   = $_POST['colour'];
    $doors    = $_POST['doors'];
    $keys    = $_POST['keys'];
    $sat_nav    = $_POST['sat_nav'];
    $mot_exp    = $_POST['mot_exp'];
    $serv_his    = $_POST['serv_his'];
    $last_serv    = $_POST['last_serv'];
    $inter_con    = $_POST['inter_con'];
    $exter_con    = $_POST['exter_con'];
    $tyre_con    = $_POST['tyre_con'];
    $warranty    = $_POST['warranty'];
    $v5_docx    = $_POST['v5_docx'];
    $hpi_check    = $_POST['hpi_check'];
    $hpi_status    = $_POST['hpi_status'];
    $category    = $_POST['category'];
    $vin    = $_POST['vin'];
    $doc_ref_num    = $_POST['doc_ref_num'];
    $id     = $_POST['id'];
    
    // Submitted user data
    $specData = array(
        'reg_num'  => $reg_num,
        'date_of_reg' => $date_of_reg,
        'mileage' => $mileage,
        'fuel_type' => $fuel_type,
        'colour' => $colour,
        'doors' => $doors,
        'keys' => $keys,
        'sat_nav' => $sat_nav,
        'mot_exp' => $mot_exp,
        'serv_his' => $serv_his,
        'last_serv' => $last_serv,
        'inter_con' => $inter_con,
        'exter_con' => $exter_con,
        'tyre_con' => $tyre_con,
        'warranty' => $warranty,
        'v5_docx' => $v5_docx,
        'hpi_check' => $hpi_check,
        'hpi_status' => $hpi_status,
        'category' => $category,
        'vin' => $vin,
        'doc_ref_num' => $doc_ref_num
    );
    
    // Store submitted data into session
    $sessData['postData'] = $specData;
    $sessData['postData']['id'] = $id;
    
    // ID query string
    $idStr = !empty($id)?'?id='.$id:'';
    
    // If the data is not empty
    if((!empty($spec['reg_num']) && !empty($reg_num)) || (!empty($id) && !empty($reg_num))){
       
        if(!empty($id)){
            // Previous file name
            $conditions['where'] = array(
                'id' => $_GET['id']
            );
            $conditions['return_type'] = 'single';
            $prevData = $db->getRows('specifications', $conditions);
            
            // Update data
            $condition = array('id' => $id);
            $update = $db->update($tblName, $specData, $condition);
            
        }
        else{
            $statusMsg = 'All fields are mandatory, please fill all the fields.';
        }
        // Status message
        $sessData['status']['type'] = $statusType;
        $sessData['status']['msg']  = $statusMsg;
    }


    elseif(($_REQUEST['action_type'] == 'block') && !empty($_GET['id'])){
        // Update data
        $specData = array('status' => 0);
        $condition = array('id' => $_GET['id']);
        $update = $db->update($tblName, $specData, $condition);
        // Status message
        $sessData['status']['type'] = $statusType;
        $sessData['status']['msg']  = $statusMsg;
    }
    
    elseif(($_REQUEST['action_type'] == 'unblock') && !empty($_GET['id'])){
        // Update data
        $specData = array('status' => 1);
        $condition = array('id' => $_GET['id']);
        $update = $db->update($tblName, $specData, $condition);
        // Status message
        $sessData['status']['type'] = $statusType;
        $sessData['status']['msg']  = $statusMsg;
    }
    
    elseif(($_REQUEST['action_type'] == 'delete') && !empty($_GET['id'])){
        // Previous file name
        $conditions['where'] = array(
            'id' => $_GET['id']
        );
        $conditions['return_type'] = 'single';
        $prevData = $db->getRows('specifications', $conditions);          
        // Delete data
        $condition = array('id' => $_GET['id']);
        $delete = $db->delete($tblName, $condition);
        if($delete){
        
            // Status message
            $sessData['status']['type'] = $statusType;
            $sessData['status']['msg']  = $statusMsg;
        }
    }
}
   
// Store status into the session
$_SESSION['sessData'] = $sessData;
    
// Redirect the user
header("Location: ".$redirectURL);
exit();
?>