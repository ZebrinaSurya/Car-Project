<?php
// Start session
session_start();

// Include and initialize DB class
require_once '../config.php';
$db = new DB();

// Fetch the users data
$images = $db->getRows('specification');

// Get session data
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';

// Get status message from session
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../../img/logo.png">
    <link rel="icon" type="image/png" href="../../img/logo.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title> Admin Dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous"/>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500&display=swap" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <?php include("../main/sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <?php include("../main/navbar.php"); ?>
            <!-- End Navbar -->


<!-- Display status message -->
<?php if(!empty($statusMsg)){ ?>
<div class="col-xs-12">
    <div class="alert alert-<?php echo $statusMsgType; ?>"><?php echo $statusMsg; ?></div>
</div>
<?php } ?>


    <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card strpied-tabled-with-hover">
                                <div class="card-header ">
                                    <div class="float-left">
                                        <h4 class="card-title">Latest Cars data</h4>
                                    </div>
                                    <div class="float-right">
                                        <a href="addEdit_spec.php" class="btn btn-success"><i class="fa fa-plus"></i> Add Data</a>
                                    </div>
                                </div>
                                <div class="card-body table-full-width table-responsive">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                        <th width="5%"></th>
                                        <th width="20%">Registration No.</th>
                                        <th width="15%">Date of Registration</th>
                                        <th width="10%">Title</th>
                                        <th width="10%">Price</th>
                                        <th width="10%">Status</th>
                                        <th width="30%">Action</th>
                                        </thead>
                                        <tbody>
                                        <?php
                                            if(!empty($images)){
                                                foreach($images as $row){
                                                    $statusLink = ($row['status'] == 1)?'postAction_spec.php?action_type=block&id='.$row['id']:'postAction_spec.php?action_type=unblock&id='.$row['id'];
                                                    $statusTooltip = ($row['status'] == 1)?'Click to Inactive':'Click to Active';
                                            ?>
                                            <tr>
                                                <td><?php echo '#'.$row['id']; ?></td>
                                                <td><?php echo $row['reg_num']; ?></td>
                                                <td><?php echo $row['date_of_reg']; ?></td>
                                                <td><?php echo $row['title']; ?></td>
                                                <td><?php echo $row['price']; ?></td>
                                                <td><a href="<?php echo $statusLink; ?>" title="<?php echo $statusTooltip; ?>"><span class="badge <?php echo ($row['status'] == 1)?'badge-success':'badge-danger'; ?>"><?php echo ($row['status'] == 1)?'Active':'Inactive'; ?></span></a></td>
                                                <td style="display: table-cell;">
                                                    <a href="view_spec.php?id=<?php echo $row['id']; ?>" class="edit_style btn btn-warning"><i class="fa fa-eye"></i>View</a>&nbsp;&nbsp;
                                                    <a href="addEdit_spec.php?id=<?php echo $row['id']; ?>" class="edit_style btn btn-primary"><i class="fa fa-edit"></i>Edit</a>&nbsp;&nbsp;
                                                    <a href="postAction_spec.php?action_type=delete&id=<?php echo $row['id']; ?>" class="delete_style btn btn-danger" onclick="return confirm('Are you sure to delete data?')?true:false;"><i class="fa fa-trash"></i>Delete</a>
                                                </td>
                                            </tr>
                                            <?php } }else{ ?>
                                            <p class="text-center">No data(s) found...</p>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
</html>



   