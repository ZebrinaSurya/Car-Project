<?php
// Start session
session_start();

// Include and initialize DB class
require_once '../config.php';
$db = new DB();
 
// Define variables and initialize with empty values
$title = $price = $reg_num = $date_of_reg = $mileage = $fuel_type = $colour = $doors = $car_key = $sat_nav = $mot_exp = $serv_his = $last_serv = $inter_con = $exter_con = $tyre_con = $warranty = $v5_docx = $hpi_check = $hpi_status = $category = $vin = $doc_ref_num =  "";

$title_err = $price_err = $reg_num_err = $date_of_reg_err = $mileage_err = $fuel_type_err = $colour_err = $doors_err = $car_key_err = $sat_nav_err = $mot_exp_err = $serv_his_err = $last_serv_err = $inter_con_err = $exter_con_err = $tyre_con_err = $warranty_err = $v5_docx_err = $hpi_check_err = $hpi_status_err = $category_err = $vin_err = $doc_ref_num_err =  "";

// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
    
    // Validate title
    $input_title = trim($_POST["title"]);
    if(empty($input_title)){
        $title_err = "Enter a title.";
    } elseif(!filter_var($input_title, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $title_err = "Enter a valid title.";
    } else{
        $title = $input_title;
    }
    
    // Validate reg_num
    $input_reg_num = trim($_POST["reg_num"]);
    if(empty($input_reg_num)){
        $reg_num_err = "Enter a valid value.";     
    } else{
        $reg_num = $input_reg_num;
    }
    
    // Validate mileage
    $input_mileage = trim($_POST["mileage"]);
    if(empty($input_mileage)){
        $mileage_err = "Enter a valid value.";     
    } else{
        $mileage = $input_mileage;
    }
    // Validate fuel_type
    $input_fuel_type = trim($_POST["fuel_type"]);
    if(empty($input_fuel_type)){
        $fuel_type_err = "Enter a valid value.";     
    } else{
        $fuel_type = $input_fuel_type;
    }
    // Validate colour
    $input_colour = trim($_POST["colour"]);
    if(empty($input_colour)){
        $colour_err = "Enter a valid value.";     
    } else{
        $colour = $input_colour;
    }
    // Validate sat_nav
    $input_sat_nav = trim($_POST["sat_nav"]);
    if(empty($input_sat_nav)){
        $sat_nav_err = "Enter a valid value.";     
    } else{
        $sat_nav = $input_sat_nav;
    }
    // Validate mot_exp
    $input_mot_exp = trim($_POST["mot_exp"]);
    if(empty($input_mot_exp)){
        $mot_exp_err = "Enter a valid value.";     
    } else{
        $mot_exp = $input_mot_exp;
    }
    // Validate date_of_reg
    $input_date_of_reg = trim($_POST["date_of_reg"]);
    if(empty($input_date_of_reg)){
        $date_of_reg_err = "Enter a valid value.";     
    } else{
        $date_of_reg = $input_date_of_reg;
    }
    // Validate serv_his
    $input_serv_his = trim($_POST["serv_his"]);
    if(empty($input_serv_his)){
        $serv_his_err = "Enter a valid value.";     
    } else{
        $serv_his = $input_serv_his;
    }
    // Validate last_serv
    $input_last_serv = trim($_POST["last_serv"]);
    if(empty($input_last_serv)){
        $last_serv_err = "Enter a valid value.";     
    } else{
        $last_serv = $input_last_serv;
    }
    // Validate inter_con
    $input_inter_con = trim($_POST["inter_con"]);
    if(empty($input_inter_con)){
        $inter_con_err = "Enter a valid value.";     
    } else{
        $inter_con = $input_inter_con;
    }
    // Validate exter_con
    $input_exter_con = trim($_POST["exter_con"]);
    if(empty($input_exter_con)){
        $exter_con_err = "Enter a valid value.";     
    } else{
        $exter_con = $input_exter_con;
    }
    // Validate tyre_con
    $input_tyre_con = trim($_POST["tyre_con"]);
    if(empty($input_tyre_con)){
        $tyre_con_err = "Enter a valid value.";     
    } else{
        $tyre_con = $input_tyre_con;
    }
    // Validate warranty
    $input_warranty = trim($_POST["warranty"]);
    if(empty($input_warranty)){
        $warranty_err = "Enter a valid value.";     
    } else{
        $warranty = $input_warranty;
    }
    // Validate v5_docx
    $input_v5_docx = trim($_POST["v5_docx"]);
    if(empty($input_v5_docx)){
        $v5_docx_err = "Enter a valid value.";     
    } else{
        $v5_docx = $input_v5_docx;
    }
    // Validate hpi_check
    $input_hpi_check = trim($_POST["hpi_check"]);
    if(empty($input_hpi_check)){
        $hpi_check_err = "Enter a valid value.";     
    } else{
        $hpi_check = $input_hpi_check;
    }
    // Validate hpi_status
    $input_hpi_status = trim($_POST["hpi_status"]);
    if(empty($input_hpi_status)){
        $hpi_status_err = "Enter a valid value.";     
    } else{
        $hpi_status = $input_hpi_status;
    }
    // Validate category
    $input_category = trim($_POST["category"]);
    if(empty($input_category)){
        $category_err = "Enter a valid value.";     
    } else{
        $category = $input_category;
    }
    // Validate vin
    $input_vin = trim($_POST["vin"]);
    if(empty($input_vin)){
        $vin_err = "Enter a valid value.";     
    } else{
        $vin = $input_vin;
    }
    // Validate doc_ref_num
    $input_doc_ref_num = trim($_POST["doc_ref_num"]);
    if(empty($input_doc_ref_num)){
        $doc_ref_num_err = "Enter a valid value.";     
    } else{
        $doc_ref_num = $input_doc_ref_num;
    }
    
    // Validate price
    $input_price = trim($_POST["price"]);
    if(empty($input_price)){
        $price_err = "Enter the price amount.";     
    } elseif(!ctype_digit($input_price)){
        $price_err = "Enter a positive integer value.";
    } else{
        $price = $input_price;
    }

    // Validate door
    $input_doors = trim($_POST["doors"]);
    if(empty($input_doors)){
        $doors_err = "Enter the doors amount.";     
    } elseif(!ctype_digit($input_doors)){
        $doors_err = "Enter a positive integer value.";
    } else{
        $doors = $input_doors;
    }
    // Validate key
    $input_car_key = trim($_POST["car_key"]);
    if(empty($input_car_key)){
        $car_key_err = "Enter the car_key amount.";     
    } elseif(!ctype_digit($input_car_key)){
        $car_key_err = "Enter a positive integer value.";
    } else{
        $car_key = $input_car_key;
    }
    
    // Check input errors before inserting in database
    if(empty($title_err) && empty($price_err) && empty($reg_num_err) && empty($date_of_reg_err) && empty($mileage_err) && empty($fuel_type_err) && empty($colour_err) && empty($doors_err) && empty($car_key_err) && empty($sat_nav_err) && empty($mot_exp_err) && empty($serv_his_err) && empty($last_serv_err) && empty($inter_con_err) && empty($exter_con_err) && empty($tyre_con_err) && empty($warranty_err) && empty($v5_docx_err) && empty($hpi_check_err) && empty($hpi_status_err) && empty($category_err) && empty($vin_err) && empty($doc_ref_num_err)){
        // Prepare an update statement
        $sql = "UPDATE spec_details SET title=?, price=?, reg_num=?, date_of_reg=?, mileage=?, fuel_type=?, colour=?, doors=?, car_key=?, sat_nav=?, mot_exp=?, serv_his=?, last_serv=?, inter_con=?, exter_con=?, tyre_con=?, warranty=?, v5_docx=?, hpi_check=?, hpi_status=?, category=?, vin=?, doc_ref_num=? WHERE id=?";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssssssssssssssssssssssi", $param_title, $param_price, $param_reg_num, $param_date_of_reg, $param_mileage, $param_fuel_type, $param_colour, $param_doors, $param_car_key, $param_sat_nav, $param_mot_exp, $param_serv_his, $param_last_serv, $param_inter_con, $param_exter_con, $param_tyre_con, $param_warranty, $param_v5_docx, $param_hpi_check, $param_hpi_status, $param_category, $param_vin, $param_doc_ref_num, $param_id);
            
            // Set parameters
            $param_title = $title;
            $param_price = $price;
            $param_reg_num = $reg_num;
            $param_date_of_reg = $date_of_reg;
            $param_mileage = $mileage;
            $param_fuel_type = $fuel_type;
            $param_colour = $colour;
            $param_doors = $doors;
            $param_car_key = $car_key;
            $param_sat_nav = $sat_nav;
            $param_mot_exp = $mot_exp;
            $param_serv_his = $serv_his;
            $param_last_serv = $last_serv;
            $param_inter_con = $inter_con;
            $param_exter_con = $exter_con;
            $param_tyre_con = $tyre_con;
            $param_warranty = $warranty;
            $param_v5_docx = $v5_docx;
            $param_hpi_check = $hpi_check;
            $param_hpi_status = $hpi_status;
            $param_category = $category;
            $param_vin = $vin;
            $param_doc_ref_num = $doc_ref_num;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM spec_details WHERE id = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $title = $row["title"];
                    $price = $row["price"];
                    $reg_num = $row["reg_num"];
                    $date_of_reg = $row["date_of_reg"];
                    $mileage = $row["mileage"];
                    $fuel_type = $row["fuel_type"];
                    $colour = $row["colour"];
                    $doors = $row["doors"];
                    $car_key = $row["car_key"];
                    $sat_nav = $row["sat_nav"];
                    $mot_exp = $row["mot_exp"];
                    $serv_his = $row["serv_his"];
                    $last_serv = $row["last_serv"];
                    $inter_con = $row["inter_con"];
                    $exter_con = $row["exter_con"];
                    $tyre_con = $row["tyre_con"];
                    $warranty = $row["warranty"];
                    $v5_docx = $row["v5_docx"];
                    $hpi_check = $row["hpi_check"];
                    $hpi_status = $row["hpi_status"];
                    $category = $row["category"];
                    $vin = $row["vin"];
                    $doc_ref_num = $row["doc_ref_num"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
       // Close statement
            mysqli_stmt_close($stmt); 
            
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        
        // Close connection
        mysqli_close($link);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>
 
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../../img/logo.png">
    <link rel="icon" type="image/png" href="../../img/logo.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title> Admin Dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous"/>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500&display=swap" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <?php include("../main/sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <?php include("../main/navbar.php"); ?>
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header ">
                                    <div class="float-left">
                                        <h4 class="card-title">Specification Details | Add Data </h4>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                                        <div class="form-group row">
                                            <div class="col-md-3">
                                                <label>Title</label>
                                                <input type="text" name="title" class="form-control <?php echo (!empty($title_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $title; ?>">
                                                <span class="invalid-feedback"><?php echo $title_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>Price</label>
                                                <input type="number" name="price" class="form-control <?php echo (!empty($price_err)) ? 'is-invalid' : ''; ?>"  value="<?php echo $price; ?>">
                                                <span class="invalid-feedback"><?php echo $price_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>Registration No.</label>
                                                <input type="text" name="reg_num" class="form-control <?php echo (!empty($reg_num_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $reg_num; ?>">
                                                <span class="invalid-feedback"><?php echo $reg_num_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>date_of_reg</label>
                                                <input type="date" name="date_of_reg" class="form-control <?php echo (!empty($date_of_reg_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $date_of_reg; ?>">
                                                <span class="invalid-feedback"><?php echo $date_of_reg_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>mileage</label>
                                                <input type="text" name="mileage" class="form-control <?php echo (!empty($mileage_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $mileage; ?>">
                                                <span class="invalid-feedback"><?php echo $mileage_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>fuel_type</label>
                                                <input type="text" name="fuel_type" class="form-control <?php echo (!empty($fuel_type_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $fuel_type; ?>">
                                                <span class="invalid-feedback"><?php echo $fuel_type_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>colour</label>
                                                <input type="text" name="colour" class="form-control <?php echo (!empty($colour_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $colour; ?>">
                                                <span class="invalid-feedback"><?php echo $colour_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>doors</label>
                                                <input type="number" name="doors" class="form-control <?php echo (!empty($doors_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $doors; ?>">
                                                <span class="invalid-feedback"><?php echo $doors_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>car_key</label>
                                                <input type="number" name="car_key" class="form-control <?php echo (!empty($car_key_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $car_key; ?>">
                                                <span class="invalid-feedback"><?php echo $car_key_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>sat_nav</label>
                                                <input type="text" name="sat_nav" class="form-control <?php echo (!empty($sat_nav_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $sat_nav; ?>">
                                                <span class="invalid-feedback"><?php echo $sat_nav_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>mot_exp</label>
                                                <input type="date" name="mot_exp" class="form-control <?php echo (!empty($mot_exp_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $mot_exp; ?>">
                                                <span class="invalid-feedback"><?php echo $mot_exp_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>serv_his</label>
                                                <input type="text" name="serv_his" class="form-control <?php echo (!empty($serv_his_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $serv_his; ?>">
                                                <span class="invalid-feedback"><?php echo $serv_his_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>last_serv</label>
                                                <input type="date" name="last_serv" class="form-control <?php echo (!empty($last_serv_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $last_serv; ?>">
                                                <span class="invalid-feedback"><?php echo $last_serv_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>inter_con</label>
                                                <input type="text" name="inter_con" class="form-control <?php echo (!empty($inter_con_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $inter_con; ?>">
                                                <span class="invalid-feedback"><?php echo $inter_con_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>exter_con</label>
                                                <input type="text" name="exter_con" class="form-control <?php echo (!empty($exter_con_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $exter_con; ?>">
                                                <span class="invalid-feedback"><?php echo $exter_con_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>tyre_con</label>
                                                <input type="text" name="tyre_con" class="form-control <?php echo (!empty($tyre_con_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $tyre_con; ?>">
                                                <span class="invalid-feedback"><?php echo $tyre_con_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>warranty</label>
                                                <input type="text" name="warranty" class="form-control <?php echo (!empty($warranty_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $warranty; ?>">
                                                <span class="invalid-feedback"><?php echo $warranty_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>v5_docx</label>
                                                <input type="text" name="v5_docx" class="form-control <?php echo (!empty($v5_docx_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $v5_docx; ?>">
                                                <span class="invalid-feedback"><?php echo $v5_docx_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>hpi_check</label>
                                                <input type="text" name="hpi_check" class="form-control <?php echo (!empty($hpi_check_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $hpi_check; ?>">
                                                <span class="invalid-feedback"><?php echo $hpi_check_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>hpi_status</label>
                                                <input type="text" name="hpi_status" class="form-control <?php echo (!empty($hpi_status_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $hpi_status; ?>">
                                                <span class="invalid-feedback"><?php echo $hpi_status_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>category</label>
                                                <input type="text" name="category" class="form-control <?php echo (!empty($category_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $category; ?>">
                                                <span class="invalid-feedback"><?php echo $category_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>vin</label>
                                                <input type="text" name="vin" class="form-control <?php echo (!empty($vin_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $vin; ?>">
                                                <span class="invalid-feedback"><?php echo $vin_err;?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label>doc_ref_num</label>
                                                <input type="text" name="doc_ref_num" class="form-control <?php echo (!empty($doc_ref_num_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $doc_ref_num; ?>">
                                                <span class="invalid-feedback"><?php echo $doc_ref_num_err;?></span>
                                            </div>
                                        </div>
                                        <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                                        <input type="submit" class="btn btn-primary" value="Submit">
                                        <a href="index.php" class="btn btn-secondary ml-2">Cancel</a>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
</html>