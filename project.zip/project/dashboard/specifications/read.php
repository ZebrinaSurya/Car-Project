<?php
// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){

// Start session
session_start();

// Include and initialize DB class
require_once '../config.php';
$db = new DB(); 
    
    // Prepare a select statement
    $sql = "SELECT * FROM spec_details WHERE id = ?";
    
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $title = $row["title"];
                $price = $row["price"];
                $reg_num = $row["reg_num"];
                $date_of_reg = $row["date_of_reg"];
                $mileage = $row["mileage"];
                $fuel_type = $row["fuel_type"];
                $colour = $row["colour"];
                $doors = $row["doors"];
                $car_key = $row["car_key"];
                $sat_nav = $row["sat_nav"];
                $mot_exp = $row["mot_exp"];
                $serv_his = $row["serv_his"];
                $last_serv = $row["last_serv"];
                $inter_con = $row["inter_con"];
                $exter_con = $row["exter_con"];
                $tyre_con = $row["tyre_con"];
                $warranty = $row["warranty"];
                $v5_docx = $row["v5_docx"];
                $hpi_check = $row["hpi_check"];
                $hpi_status = $row["hpi_status"];
                $category = $row["category"];
                $vin = $row["vin"];
                $doc_ref_num = $row["doc_ref_num"];
            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($link);
} else{
    // URL doesn't contain id parameter. Redirect to error page
    header("location: error.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../../img/logo.png">
    <link rel="icon" type="image/png" href="../../img/logo.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title> Admin Dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous"/>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500&display=swap" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <?php include("../main/sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <?php include("../main/navbar.php"); ?>


            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card strpied-tabled-with-hover">
                                <div class="card-header ">
                                    <div class="float-left">
                                        <h4 class="card-title">Specifications data</h4>
                                    </div>
                                </div>
                                <div class="card-body table-full-width table-responsive">
                                    <div class="row mx-3">
                                        
                                    <div class="col-md-6">
                                            <table class="table table-hover table-striped">
                                                <tbody>
                                                    <tr>
                                                        <td>Title</td>
                                                        <td><b><?php echo $row["title"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Price</td>
                                                        <td><b><?php echo $row["price"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Registration Number</td>
                                                        <td><b><?php echo $row["reg_num"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Date of Registration</td>
                                                        <td><b><?php echo $row["date_of_reg"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Mileage</td>
                                                        <td><b><?php echo $row["mileage"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Type of Fuel</td>
                                                        <td><b><?php echo $row["fuel_type"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Colour</td>
                                                        <td><b><?php echo $row["colour"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Number of doors</td>
                                                        <td><b><?php echo $row["doors"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Number of keys</td>
                                                        <td><b><?php echo $row["car_key"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Sat Nav</td>
                                                        <td><b><?php echo $row["sat_nav"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>MOT Expire date</td>
                                                        <td><b><?php echo $row["mot_exp"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Service history</td>
                                                        <td><b><?php echo $row["serv_his"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Last Serviced on</td>
                                                        <td><b><?php echo $row["last_serv"]; ?></b></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-md-6">
                                            <table class="table table-hover table-striped">
                                                <tbody>
                                                    <tr>
                                                        <td>Interior Condition</td>
                                                        <td><b><?php echo $row["inter_con"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Exterior Condition</td>
                                                        <td><b><?php echo $row["exter_con"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Tyre Condition</td>
                                                        <td><b><?php echo $row["tyre_con"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Warranty</td>
                                                        <td><b><?php echo $row["warranty"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>V5 Document</td>
                                                        <td><b><?php echo $row["v5_docx"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>HPI Check</td>
                                                        <td><b><?php echo $row["hpi_check"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>HPI status</td>
                                                        <td><b><?php echo $row["hpi_status"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Category</td>
                                                        <td><b><?php echo $row["category"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>VIN/Chassls/Frame Number</td>
                                                        <td><b><?php echo $row["vin"]; ?></b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Document Reference Number</td>
                                                        <td><b><?php echo $row["doc_ref_num"]; ?></b></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <p><a href="index.php" class="btn btn-primary">Back</a></p>     

                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                   
                   
               
    
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
</html>