<?php
// Start session
session_start();

// Include and initialize DB class
require_once '../config.php';
$db = new DB();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../../img/logo.png">
    <link rel="icon" type="image/png" href="../../img/logo.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title> Admin Dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous"/>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500&display=swap" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <?php include("../main/sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <?php include("../main/navbar.php"); ?>
   

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card strpied-tabled-with-hover">
                                <div class="card-header ">
                                    <div class="float-left">
                                        <h4 class="card-title">Specifications data</h4>
                                    </div>
                                    <div class="float-right">
                                        <a href="create.php" class="btn btn-success"><i class="fa fa-plus"></i> Add Data</a>
                                    </div>
                                </div>
                                <div class="card-body table-full-width table-responsive">
                                    <?php
                                    // Include config file
                                    require_once "../config.php";
                                    
                                    // Attempt select query execution
                                    $sql = "SELECT * FROM spec_details";
                                    if($result = mysqli_query($link, $sql)){
                                        if(mysqli_num_rows($result) > 0){
                                            echo '<table class="table table-hover table-striped">';
                                                echo "<thead>";
                                                    echo "<tr>";
                                                        echo "<th>#</th>";
                                                        echo "<th>Title</th>";
                                                        echo "<th>Price</th>";
                                                        echo "<th>Registration No.</th>";
                                                        echo "<th>Date of Registration</th>";
                                                        echo "<th>Colour</th>";
                                                        echo "<th>Mileage</th>";
                                                        echo "<th>Last Service</th>";
                                                        echo "<th>Warrenty</th>";
                                                        echo "<th>Action</th>";
                                                    echo "</tr>";
                                                echo "</thead>";
                                                echo "<tbody>";
                                                while($row = mysqli_fetch_array($result)){
                                                    echo "<tr>";
                                                        echo "<td>" . $row['id'] . "</td>";
                                                        echo "<td>" . $row['title'] . "</td>";
                                                        echo "<td>$" . $row['price'] . "</td>";
                                                        echo "<td>" . $row['reg_num'] . "</td>";
                                                        echo "<td>" . $row['date_of_reg'] . "</td>";
                                                        echo "<td>" . $row['colour'] . "</td>";
                                                        echo "<td>" . $row['mileage'] . "</td>";
                                                        echo "<td>" . $row['last_serv'] . "</td>";
                                                        echo "<td>" . $row['warranty'] . "</td>";
                                                        echo "<td>";
                                                            echo '<a href="read.php?id='. $row['id'] .'" class="view_style btn btn-warning"><i class="fa fa-eye"></i>View</a>&nbsp;&nbsp;';
                                                            echo '<a href="update.php?id='. $row['id'] .'"class="edit_style btn btn-primary"><i class="fa fa-edit"></i>Edit</a>&nbsp;&nbsp;';
                                                            echo '<a href="delete.php?id='. $row['id'] .'" class="delete_style btn btn-danger"><i class="fa fa-trash"></i>Delete</a>';
                                                        echo "</td>";
                                                    echo "</tr>";
                                                }
                                                echo "</tbody>";                            
                                            echo "</table>";
                                            // Free result set
                                            mysqli_free_result($result);
                                        } else{
                                            echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                                        }
                                    } else{
                                        echo "Oops! Something went wrong. Please try again later.";
                                    }
                
                                    // Close connection
                                    mysqli_close($link);
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
</html>