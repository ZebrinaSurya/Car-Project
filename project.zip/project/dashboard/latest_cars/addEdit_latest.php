<?php
// Start session
session_start();

$postData = $imgData = array();

// Get session data
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';

// Get status message from session
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}

// Get posted data from session
if(!empty($sessData['postData'])){
    $postData = $sessData['postData'];
    unset($_SESSION['sessData']['postData']);
}

// Get image data
if(!empty($_GET['id'])){
    // Include and initialize DB class
    require_once '../config.php';
    $db = new DB();
    
    $conditions['where'] = array(
        'id' => $_GET['id'],
    );
    $conditions['return_type'] = 'single';
    $imgData = $db->getRows('latest_cars', $conditions);
}

// Pre-filled data
$imgData = !empty($postData)?$postData:$imgData;

// Define action
$actionLabel = !empty($_GET['id'])?'Edit':'Add';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../../img/logo.png">
    <link rel="icon" type="image/png" href="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title> Admin Dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous"/>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500&display=swap" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <?php include("../main/sidebar.php"); ?>
        <div class="main-panel">
            <!-- Navbar -->
            <?php include("../main/navbar.php"); ?>
            <!-- End Navbar -->



<!-- Display status message -->
<?php if(!empty($statusMsg)){ ?>
<div class="col-xs-12">
    <div class="alert alert-<?php echo $statusMsgType; ?>"><?php echo $statusMsg; ?></div>
</div>
<?php } ?>


            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header ">
                                    <div class="float-left">
                                        <h4 class="card-title">Latest Cars | Add Data </h4>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <form method="post" action="postAction_latest.php" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label>Image</label>
                                            <?php if(!empty($imgData['file_name'])){ ?>
                                                <img width="250" style="padding:10px" src="../uploads/latest_cars/<?php echo $imgData['file_name']; ?>">
                                            <?php } ?>
                                            <input type="file" name="image" class="form-control" >
                                        </div>
                                        <div class="form-group">
                                            <label>Title</label>
                                            <input type="text" name="title" class="form-control" placeholder="Enter title" value="<?php echo !empty($imgData['title'])?$imgData['title']:''; ?>" >
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-6">
                                                <label>Price</label>
                                                <input type="number" name="price" class="form-control" placeholder="Enter Price" value="<?php echo !empty($imgData['price'])?$imgData['price']:''; ?>" >
                                            </div>
                                            <div class="col-md-6">
                                                <label>Year</label>
                                                <input type="number" name="year" class="form-control" placeholder="Enter Year" value="<?php echo !empty($imgData['year'])?$imgData['year']:''; ?>" >
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-4">
                                                <label>Engine Size</label>
                                                <input type="number" name="engine_size" class="form-control" placeholder="Enter Engine Size" value="<?php echo !empty($imgData['engine_size'])?$imgData['engine_size']:''; ?>" >
                                            </div>
                                            <div class="col-md-4">
                                                <label>Transmission</label>
                                                <input type="text" name="transmission" class="form-control" placeholder="Enter Transmission" value="<?php echo !empty($imgData['transmission'])?$imgData['transmission']:''; ?>" >
                                            </div>
                                            <div class="col-md-4">
                                                <label>Oil</label>
                                                <input type="text" name="oil" class="form-control" placeholder="Enter Oil" value="<?php echo !empty($imgData['oil'])?$imgData['oil']:''; ?>" >
                                            </div>
                                        </div>
                                        <a href="manage_latest.php" class="btn btn-secondary">Back</a>
                                        <input type="hidden" name="id" value="<?php echo !empty($imgData['id'])?$imgData['id']:''; ?>">
                                        <input type="submit" name="imgSubmit" class="btn btn-success" value="SUBMIT">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
</html>


